<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "CTVPortal";

$conn = new mysqli($servername, $username,'',$dbname);


if ($conn->connect_error) {
	
    die("Connection failed: " . $conn->connect_error);
}
else
{ 
//echo "Connected Database successfully";
}

?>
<!doctype html>
<html>
<head>

<link rel="stylesheet" href="style.css"> 

</head>
<body>

<h1 align="center">*************Doctors RECORD Print **********</h1>

<table border="1" align="center" style="line-height:25px;">
<tr>
<th> Doctor_id</th>
<th> Dname</th>
<th> AgeGroup</th>
<th> ApprovedStatus</th>
<th> Doc_Remakrs</th>
<th> DYear</th>
<th> Specialist_id</th>
<th> Disease</th>


</tr>
<?php
$sql = "SELECT * FROM Doctors";
$result = $conn->query($sql);
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>


<td> <?php  echo $row['Doctor_id']		;?></td>
<td> <?php  echo $row['Dname']			;?></td>
<td> <?php  echo $row['AgeGroup']		;?></td>
<td> <?php  echo $row['ApprovedStatus']	;?></td>
<td> <?php  echo $row['Doc_Remakrs']	;?></td>
<td> <?php  echo $row['DYear']			;?></td>
<td> <?php  echo $row['Specialist_id']	;?></td>
<td> <?php  echo $row['Disease']		;?></td>

 </tr>
 <?php
 }
 }
 else
 {
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table>
</body>
</html>