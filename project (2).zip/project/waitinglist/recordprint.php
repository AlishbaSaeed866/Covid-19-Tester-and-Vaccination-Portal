<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "CTVPortal";

$conn = new mysqli($servername, $username,'',$dbname);


if ($conn->connect_error) {
	
    die("Connection failed: " . $conn->connect_error);
}
else
{ 
//echo "Connected Database successfully";
}

?>
<!doctype html>
<html>
<head>

<link rel="stylesheet" href="style.css"> 

</head>
<body>

<h1 align="center">*************WaitingList RECORD Print **********</h1>

<table border="1" align="center" style="line-height:25px;">
<tr>
<th>Waiting_ID</th>
<th>Province</th>
<th>Age</th>

</tr>
<?php
$sql = "SELECT * FROM WaitingList";
$result = $conn->query($sql);
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>

<td> <?php  echo $row['Waiting_ID'];?></td>
<td> <?php  echo $row['Province'];?></td>
<td> <?php  echo $row['Age'];?></td>

 </tr>
 <?php
 }
 }
 else
 {
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table>
</body>
</html>