<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "CTVPortal";

$conn = new mysqli($servername, $username,'',$dbname);


if ($conn->connect_error) {
	
    die("Connection failed: " . $conn->connect_error);
}
else
{ 
//echo "Connected Database successfully";
}

?>
<!doctype html>
<html>
<head>

<link rel="stylesheet" href="style.css"> 

</head>
<body>

<h1 align="center">Patients RECORD Update</h1>

<table border="1" align="center" style="line-height:25px;">
<tr>
<th> Cnic           </th>
<th> Pname          </th>
<th> Age            </th>
<th> Gender			</th>
<th> dob			</th>
<th> Address		</th>
<th> Temperature	</th>
<th> BloodPressure	</th>

</tr>
<?php
$sql = "SELECT * FROM Patients";
$result = $conn->query($sql);
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>

<td> <?php  echo $row['Cnic'];?></td>
<td> <?php  echo $row['Pname'];?></td>
<td> <?php  echo $row['Age'];?></td>
<td> <?php  echo $row['Gender'];?></td>
<td> <?php  echo $row['dob'];?></td>
<td> <?php  echo $row['Address'];?></td>
<td> <?php  echo $row['Temperature'];?></td>
<td> <?php  echo $row['BloodPressure'];?></td>

 <td><a href="edit.php?edit_id=<?php echo $row['Cnic']; ?>" alt="edit" >Edit/update</a></td>
 </tr>
 <?php
 }
 }
 else
 {
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table>
</body>
</html>