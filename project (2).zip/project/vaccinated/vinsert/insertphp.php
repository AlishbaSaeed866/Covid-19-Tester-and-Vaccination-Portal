<?php
$a= $_POST['a'];
$b= $_POST['b'];




$servername = "localhost";
$username = "root";
$password = "";
$dbname = "CTVPortal";

// Create connection
$conn = new mysqli($servername, $username,'',$dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
{ 
echo "Connected successfully";
}

$q="INSERT INTO Vaccinated VALUES('$a','$b')";
if ($conn->query($q) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $q . "<br>" . $conn->error;
}

?>