<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "CTVPortal";

$conn = new mysqli($servername, $username,'',$dbname);


if ($conn->connect_error) {
	
    die("Connection failed: " . $conn->connect_error);
}
else
{ 
//echo "Connected Database successfully";
}

?>
<!doctype html>
<html>
<head>

<link rel="stylesheet" href="style.css"> 

</head>
<body>

<h1 align="center">*************doctors RECORD Print **********</h1>

<table border="1" align="center" style="line-height:25px;">
<tr>
<th> QS_id</th>
<th> P_id</th>
<th> S_id</th>
<th> start_date</th>
<th> End_date</th>
<th> HealthReport</th>
<th> Major_Symptoms</th>


</tr>
<?php
$sql = "SELECT * FROM QarantineSupport";
$result = $conn->query($sql);
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>


<td> <?php  echo $row['QS_id']		    ;?></td>
<td> <?php  echo $row['P_id']		    ;?></td>
<td> <?php  echo $row['S_id']		    ;?></td>
<td> <?php  echo $row['start_date']	    ;?></td>
<td> <?php  echo $row['End_date']	    ;?></td>
<td> <?php  echo $row['HealthReport']	;?></td>
<td> <?php  echo $row['Major_Symptoms']	;?></td>

 </tr>
 <?php
 }
 }
 else
 {
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table>
</body>
</html>